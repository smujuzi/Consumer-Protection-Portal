from django.apps import AppConfig


class HostingConfig(AppConfig):
    name = 'protect'
